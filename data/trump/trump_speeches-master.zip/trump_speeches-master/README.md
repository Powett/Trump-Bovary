# trump_speeches
All of Trump's Speeches from June 2015 to November 9, 2016

Missing line breaks and other formatting, but should work well for most text analysis purposes. Enjoy. 
